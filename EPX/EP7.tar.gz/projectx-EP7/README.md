# Project X

A community driven modular blockchain created from scratch
